import numpy as np
from legacycontour import _cntr as cntr
#import matplotlib._cntr as cntr
from shapely.geometry import Point, Polygon
from astropy.io import fits
import time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Note: To run the code you need to install shapley and legacycontour.
#       shapley can be installed by "pip install shapley". The installation for "legacycontour" is not straightforward but still easy.
#       _cntr has been removed from matplotlib as it seems to be a private package from matlab.
#       However, matplotlib group keeps it in the legacycontour project.
#       To install legacycontour, you need to "git clone https://github.com/matplotlib/legacycontour.git"
#       Go into the directory and "python setup.py install".



def random_points_in_polygon(polygons, number):
    '''
    This function is to draw random points within some polygons.
    
    polygons: the polygons are obtained through matplotlib's contour plotting module, and wrapped by shapely.geometry.Polygon
    number: number of sample points
    '''
    points = np.zeros((number, 2))
    num_polygon = len(polygons)
    
    # set the box to randomly draw points, minx, miny, maxx, maxy are the boundaries of the box.
    
    min_list = np.zeros((num_polygon, 4))
    for i, polygon in enumerate(polygons):
        tempminx, tempminy, tempmaxx, tempmaxy = polygon.bounds
        min_list[i][0] = tempminx
        min_list[i][1] = tempminy
        min_list[i][2] = tempmaxx
        min_list[i][3] = tempmaxy
    minx = np.min(min_list[:, 0]) 
    miny = np.min(min_list[:, 1])
    maxx = np.max(min_list[:, 2])
    maxy = np.max(min_list[:, 3])

    k = 0
    while k < number:
        pnt = Point(np.random.uniform(minx, maxx), np.random.uniform(miny, maxy))
        for polygon in polygons:
            if polygon.contains(pnt):
                points[k][0] = pnt.x
                points[k][1] = pnt.y
                k += 1
    return np.array(points)

test_img = fits.open('./test_img.fits')[0].data
test_img = test_img[::-1, :]

img_size = np.shape(test_img)[0]
pixel_size = 0.05
img_length = (img_size + 1.0) / 2.0 * pixel_size

coordiantes_1d = np.linspace(-img_length, img_length, img_size)
xs, ys = np.meshgrid(coordiantes_1d, coordiantes_1d)
ys = ys[::-1, :]
# the coordiantes of the image pixels needed to be input

t1 = time.time()
level = 0.01
cs = cntr.Cntr(xs, ys, test_img)
nlist = cs.trace(level, level, 0)
cs_segs = nlist[:len(nlist)//2]
#print(cs_segs)

polygons = []
for segs in cs_segs:
    polygons.append(Polygon(segs))
# We wrap those polygons by shapely.geometry.Polygon

rps = random_points_in_polygon(polygons=polygons, number=1000)
# We draw 1000 points.

t2 = time.time()
print('Time cost: {:.2f}s'.format(t2 - t1))

plt.imshow(test_img, cmap='jet', extent=[-img_length, img_length, -img_length, img_length])
plt.contour(xs, ys, test_img, levels=[level], colors='orange', linestyles='dashed', linewidths=2.0)
plt.plot(rps[:, 0], rps[:, 1], 'w.', markersize=2.0)
plt.savefig('./test_result.png')